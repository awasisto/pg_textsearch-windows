https://github.com/awasisto/pg_textsearch-windows
-------------------------------------------------

- ONLY for PostgreSQL v17 - Windows x64
- Stop PostgreSQL using services.msc
- Extract the zip file to your PostgreSQL installation folder. On the overwrite dialog option, choose "Yes to all"
- Edit postgresql.conf in your PostgreSQL data folder:
    shared_preload_libraries = 'pg_textsearch'
- Start PostgreSQL service
- Run this query to load the extension: 
    CREATE EXTENSION pg_textsearch;
- Run this query to check if the extension is enabled:
    SELECT extname, extrelocatable, extversion FROM pg_extension where extname='pg_textsearch';

